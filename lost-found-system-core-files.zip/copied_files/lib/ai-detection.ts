import { spawn } from 'child_process'
import { writeFile, readFile, unlink } from 'fs/promises'
import { join } from 'path'
import { existsSync } from 'fs'

export interface DetectionSettings {
  stationaryThreshold: number // minutes
  confidenceThreshold: number
  proximityThreshold: number
  enableAutoReporting: boolean
  monitoredClasses: string[]
  locationName: string
  cameraInfo: string
}

export interface DetectedObject {
  id: string
  class: string
  confidence: number
  bbox: [number, number, number, number]
  center: [number, number]
  frame_number: number
  timestamp: number
}

export interface LostObject {
  id: string
  class: string
  confidence: number
  bbox: [number, number, number, number]
  center: [number, number]
  first_seen: number
  last_seen: number
  duration: number
  stationary_duration_minutes: number
  total_detections: number
  average_movement: number
  best_frame: number
  capture_timestamp: number
}

export interface DetectionResults {
  video_info: {
    path: string
    duration: number
    fps: number
    total_frames: number
  }
  settings: DetectionSettings
  detected_objects: DetectedObject[]
  lost_objects: LostObject[]
  processing_stats: {
    frames_processed: number
    objects_detected: number
    tracks_created: number
    lost_objects_found: number
  }
}

export class AIDetectionService {
  private pythonPath: string
  private scriptPath: string
  private modelPath: string

  constructor() {
    this.pythonPath = process.env.PYTHON_PATH || 'python3'
    this.scriptPath = join(process.cwd(), 'scripts', 'yolo_detector.py')
    this.modelPath = join(process.cwd(), 'models', 'yolov8n.pt')
  }

  async isYOLOAvailable(): Promise<boolean> {
    try {
      const result = await this.runPythonCommand(['-c', 'import ultralytics; print("OK")'])
      return result.stdout.trim() === 'OK'
    } catch (error) {
      console.warn('YOLOv8 not available:', error)
      return false
    }
  }

  async downloadYOLOModel(): Promise<void> {
    if (existsSync(this.modelPath)) {
      return
    }

    console.log('Downloading YOLOv8 model...')
    
    // Create models directory
    const modelsDir = join(process.cwd(), 'models')
    if (!existsSync(modelsDir)) {
      const { mkdir } = await import('fs/promises')
      await mkdir(modelsDir, { recursive: true })
    }

    // Download model using Python
    try {
      await this.runPythonCommand([
        '-c', 
        `from ultralytics import YOLO; model = YOLO('yolov8n.pt'); model.export()`
      ])
      console.log('YOLOv8 model downloaded successfully')
    } catch (error) {
      console.error('Failed to download YOLOv8 model:', error)
      throw new Error('Could not download YOLOv8 model')
    }
  }

  async processVideo(videoPath: string, settings: DetectionSettings): Promise<DetectionResults> {
    if (!existsSync(videoPath)) {
      throw new Error(`Video file not found: ${videoPath}`)
    }

    if (!existsSync(this.scriptPath)) {
      throw new Error(`Python script not found: ${this.scriptPath}`)
    }

    // Check if YOLOv8 is available
    const yoloAvailable = await this.isYOLOAvailable()
    if (!yoloAvailable) {
      console.warn('YOLOv8 not available, using mock detection')
      return this.mockDetection(videoPath, settings)
    }

    // Download model if needed
    await this.downloadYOLOModel()

    // Create temporary settings file
    const settingsPath = join(process.cwd(), 'temp', `settings_${Date.now()}.json`)
    const outputPath = join(process.cwd(), 'temp', `results_${Date.now()}.json`)

    try {
      // Ensure temp directory exists
      const tempDir = join(process.cwd(), 'temp')
      if (!existsSync(tempDir)) {
        const { mkdir } = await import('fs/promises')
        await mkdir(tempDir, { recursive: true })
      }

      // Write settings file
      await writeFile(settingsPath, JSON.stringify({
        confidence_threshold: settings.confidenceThreshold,
        stationary_threshold: settings.stationaryThreshold,
        proximity_threshold: settings.proximityThreshold,
        frame_skip: 30, // Process every 30th frame for performance
        monitored_classes: settings.monitoredClasses
      }))

      // Run Python detection script
      const args = [
        this.scriptPath,
        videoPath,
        '--settings', settingsPath,
        '--output', outputPath,
        '--model', this.modelPath
      ]

      console.log('Starting AI detection process...')
      const result = await this.runPythonCommand(args)

      if (result.stderr) {
        console.warn('Python script warnings:', result.stderr)
      }

      // Read results
      if (!existsSync(outputPath)) {
        throw new Error('Detection script did not produce output file')
      }

      const resultsData = await readFile(outputPath, 'utf-8')
      const results: DetectionResults = JSON.parse(resultsData)

      // Clean up temporary files
      await Promise.allSettled([
        unlink(settingsPath),
        unlink(outputPath)
      ])

      console.log(`AI detection completed. Found ${results.lost_objects.length} potential lost objects`)
      
      return results

    } catch (error) {
      // Clean up temporary files on error
      await Promise.allSettled([
        unlink(settingsPath).catch(() => {}),
        unlink(outputPath).catch(() => {})
      ])

      console.error('Error in AI detection:', error)
      throw error
    }
  }

  private async runPythonCommand(args: string[]): Promise<{ stdout: string; stderr: string }> {
    return new Promise((resolve, reject) => {
      const process = spawn(this.pythonPath, args)
      
      let stdout = ''
      let stderr = ''

      process.stdout.on('data', (data) => {
        stdout += data.toString()
      })

      process.stderr.on('data', (data) => {
        stderr += data.toString()
      })

      process.on('close', (code) => {
        if (code === 0) {
          resolve({ stdout, stderr })
        } else {
          reject(new Error(`Python process exited with code ${code}: ${stderr}`))
        }
      })

      process.on('error', (error) => {
        reject(error)
      })
    })
  }

  private async mockDetection(videoPath: string, settings: DetectionSettings): Promise<DetectionResults> {
    console.log('Using mock AI detection (YOLOv8 not available)')
    
    // Get video duration using ffprobe (if available) or estimate
    let duration = 1800 // Default 30 minutes
    
    try {
      const ffprobeResult = await this.runCommand('ffprobe', [
        '-v', 'quiet',
        '-print_format', 'json',
        '-show_format',
        videoPath
      ])
      
      const metadata = JSON.parse(ffprobeResult.stdout)
      duration = parseFloat(metadata.format.duration) || duration
    } catch (error) {
      console.warn('Could not get video duration, using default')
    }

    // Generate mock detection results
    const mockObjects: DetectedObject[] = []
    const mockLostObjects: LostObject[] = []

    // Simulate object detection
    const numFrames = Math.floor(duration * 30) // 30 FPS
    const processedFrames = Math.floor(numFrames / 30) // Every 30th frame

    for (let i = 0; i < processedFrames; i++) {
      if (Math.random() < 0.1) { // 10% chance per frame
        const frameNumber = i * 30
        const timestamp = frameNumber / 30

        const objectClass = settings.monitoredClasses[
          Math.floor(Math.random() * settings.monitoredClasses.length)
        ]

        const obj: DetectedObject = {
          id: `mock_${frameNumber}_${Math.random().toString(36).substr(2, 9)}`,
          class: objectClass,
          confidence: Math.max(settings.confidenceThreshold, 0.7 + Math.random() * 0.3),
          bbox: [
            Math.floor(Math.random() * 400),
            Math.floor(Math.random() * 300),
            Math.floor(Math.random() * 100) + 50,
            Math.floor(Math.random() * 100) + 60
          ],
          center: [Math.floor(Math.random() * 640), Math.floor(Math.random() * 480)],
          frame_number: frameNumber,
          timestamp
        }

        mockObjects.push(obj)
      }
    }

    // Generate mock lost objects (simulate stationary detection)
    if (mockObjects.length > 0) {
      const groups = this.groupObjectsByProximity(mockObjects, settings.proximityThreshold)
      
      for (const group of groups) {
        if (group.length >= 3) { // Need multiple detections
          const firstObj = group[0]
          const lastObj = group[group.length - 1]
          const stationaryDuration = (lastObj.timestamp - firstObj.timestamp) / 60

          if (stationaryDuration >= settings.stationaryThreshold) {
            const avgConfidence = group.reduce((sum, obj) => sum + obj.confidence, 0) / group.length
            
            const lostObject: LostObject = {
              id: `mock_lost_${Date.now()}_${Math.random().toString(36).substr(2, 9)}`,
              class: firstObj.class,
              confidence: avgConfidence,
              bbox: firstObj.bbox,
              center: firstObj.center,
              first_seen: firstObj.timestamp,
              last_seen: lastObj.timestamp,
              duration: lastObj.timestamp - firstObj.timestamp,
              stationary_duration_minutes: stationaryDuration,
              total_detections: group.length,
              average_movement: Math.random() * 20, // Mock low movement
              best_frame: group[Math.floor(group.length / 2)].frame_number,
              capture_timestamp: group[Math.floor(group.length / 2)].timestamp
            }

            mockLostObjects.push(lostObject)
          }
        }
      }
    }

    return {
      video_info: {
        path: videoPath,
        duration,
        fps: 30,
        total_frames: numFrames
      },
      settings,
      detected_objects: mockObjects,
      lost_objects: mockLostObjects,
      processing_stats: {
        frames_processed: processedFrames,
        objects_detected: mockObjects.length,
        tracks_created: mockLostObjects.length,
        lost_objects_found: mockLostObjects.length
      }
    }
  }

  private groupObjectsByProximity(objects: DetectedObject[], threshold: number): DetectedObject[][] {
    const groups: DetectedObject[][] = []
    const used = new Set<string>()

    for (const obj of objects) {
      if (used.has(obj.id)) continue

      const group = [obj]
      used.add(obj.id)

      // Find similar objects
      for (const other of objects) {
        if (used.has(other.id) || obj.class !== other.class) continue

        const distance = Math.sqrt(
          Math.pow(obj.center[0] - other.center[0], 2) +
          Math.pow(obj.center[1] - other.center[1], 2)
        )

        if (distance < threshold) {
          group.push(other)
          used.add(other.id)
        }
      }

      if (group.length > 1) {
        // Sort by timestamp
        group.sort((a, b) => a.timestamp - b.timestamp)
        groups.push(group)
      }
    }

    return groups
  }

  private async runCommand(command: string, args: string[]): Promise<{ stdout: string; stderr: string }> {
    return new Promise((resolve, reject) => {
      const process = spawn(command, args)
      
      let stdout = ''
      let stderr = ''

      process.stdout.on('data', (data) => {
        stdout += data.toString()
      })

      process.stderr.on('data', (data) => {
        stderr += data.toString()
      })

      process.on('close', (code) => {
        if (code === 0) {
          resolve({ stdout, stderr })
        } else {
          reject(new Error(`Command ${command} exited with code ${code}: ${stderr}`))
        }
      })

      process.on('error', (error) => {
        reject(error)
      })
    })
  }
}

// Export singleton instance
export const aiDetectionService = new AIDetectionService()