with open('test_created.txt', 'w') as f:
    f.write('This file was created by Python\n') 