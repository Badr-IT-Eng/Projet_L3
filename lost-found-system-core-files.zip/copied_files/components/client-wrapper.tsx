"use client"

import { Navbar } from "./navbar"

export function ClientWrapper() {
  return <Navbar />
} 