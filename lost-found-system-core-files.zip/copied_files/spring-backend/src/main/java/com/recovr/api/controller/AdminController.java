package com.recovr.api.controller;

import com.recovr.api.dto.AdminDashboardDto;
import com.recovr.api.dto.ItemDto;
import com.recovr.api.dto.UserDto;
import com.recovr.api.service.AdminService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/api/admin")
@Tag(name = "Admin", description = "Admin dashboard endpoints")
public class AdminController {

    @Autowired
    private AdminService adminService;

    @GetMapping("/dashboard")
    @PreAuthorize("hasRole('ADMIN')")
    @Operation(summary = "Get admin dashboard statistics", description = "Returns statistics for the admin dashboard.")
    public ResponseEntity<AdminDashboardDto> getAdminDashboard() {
        AdminDashboardDto dashboard = adminService.getAdminDashboard();
        return ResponseEntity.ok(dashboard);
    }

    @GetMapping("/items")
    @PreAuthorize("hasRole('ADMIN')")
    @Operation(summary = "Get all items (admin)", description = "Retrieves the list of all items for administration.")
    public ResponseEntity<List<ItemDto>> getAllItemsAdmin() {
        List<ItemDto> items = adminService.getAllItemsAdmin();
        return ResponseEntity.ok(items);
    }

    @GetMapping("/users")
    @PreAuthorize("hasRole('ADMIN')")
    @Operation(summary = "Get all users (admin)", description = "Retrieves the list of all users for administration.")
    public ResponseEntity<List<UserDto>> getAllUsersAdmin() {
        List<UserDto> users = adminService.getAllUsersAdmin();
        return ResponseEntity.ok(users);
    }

    @DeleteMapping("/items/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    @Operation(summary = "Delete an item (admin)", description = "Deletes an item by its ID for administration.")
    public ResponseEntity<Void> deleteItemAdmin(@PathVariable Long id) {
        adminService.deleteItemAdmin(id);
        return ResponseEntity.noContent().build();
    }

    @DeleteMapping("/users/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    @Operation(summary = "Delete a user (admin)", description = "Deletes a user by its ID for administration.")
    public ResponseEntity<Void> deleteUserAdmin(@PathVariable Long id) {
        adminService.deleteUserAdmin(id);
        return ResponseEntity.noContent().build();
    }

    @PutMapping("/items/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    @Operation(summary = "Update an item (admin)", description = "Updates an item by its ID for administration.")
    public ResponseEntity<ItemDto> updateItemAdmin(@PathVariable Long id, @RequestBody ItemDto itemDto) {
        ItemDto updated = adminService.updateItemAdmin(id, itemDto);
        return ResponseEntity.ok(updated);
    }

    @PutMapping("/users/{id}")
    @PreAuthorize("hasRole('ADMIN')")
    @Operation(summary = "Update a user (admin)", description = "Updates a user by its ID for administration.")
    public ResponseEntity<UserDto> updateUserAdmin(@PathVariable Long id, @RequestBody UserDto userDto) {
        UserDto updated = adminService.updateUserAdmin(id, userDto);
        return ResponseEntity.ok(updated);
    }

    @PatchMapping("/users/{id}/status")
    @PreAuthorize("hasRole('ADMIN')")
    @Operation(summary = "Update user status (admin)", description = "Updates a user's status (active/inactive/suspended) for administration.")
    public ResponseEntity<?> updateUserStatus(@PathVariable Long id, @RequestBody Map<String, String> request) {
        String status = request.get("status");
        adminService.updateUserStatus(id, status);
        return ResponseEntity.ok(Map.of("success", true, "message", "User status updated successfully"));
    }

    @PatchMapping("/users/bulk")
    @PreAuthorize("hasRole('ADMIN')")
    @Operation(summary = "Bulk user operations (admin)", description = "Performs bulk operations on users (activate/suspend/delete).")
    public ResponseEntity<?> bulkUserOperation(@RequestBody Map<String, Object> request) {
        @SuppressWarnings("unchecked")
        List<Long> userIds = (List<Long>) request.get("userIds");
        String action = (String) request.get("action");
        
        int affectedUsers = adminService.bulkUserOperation(userIds, action);
        return ResponseEntity.ok(Map.of(
            "success", true, 
            "message", "Bulk " + action + " completed for " + affectedUsers + " users",
            "affectedUsers", affectedUsers
        ));
    }

    @PostMapping("/users")
    @PreAuthorize("hasRole('ADMIN')")
    @Operation(summary = "Create a new user (admin)", description = "Creates a new user account.")
    public ResponseEntity<UserDto> createUser(@RequestBody Map<String, String> request) {
        UserDto newUser = adminService.createUser(request);
        return ResponseEntity.ok(newUser);
    }
}