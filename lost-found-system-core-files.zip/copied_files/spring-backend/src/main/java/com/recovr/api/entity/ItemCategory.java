package com.recovr.api.entity;

public enum ItemCategory {
    ELECTRONICS,
    CLOTHING,
    ACCESSORIES,
    DOCUMENTS,
    KEYS,
    BAGS,
    JEWELRY,
    TOYS,
    BOOKS,
    MISCELLANEOUS
} 