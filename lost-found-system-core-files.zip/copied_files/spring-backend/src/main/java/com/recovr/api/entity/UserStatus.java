package com.recovr.api.entity;

public enum UserStatus {
    ACTIVE,
    INACTIVE,
    SUSPENDED
}