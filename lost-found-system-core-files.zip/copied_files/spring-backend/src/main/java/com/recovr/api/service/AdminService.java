package com.recovr.api.service;

import com.recovr.api.dto.AdminDashboardDto;
import com.recovr.api.dto.ItemDto;
import com.recovr.api.dto.UserDto;
import com.recovr.api.entity.Item;
import com.recovr.api.entity.ItemCategory;
import com.recovr.api.entity.ItemStatus;
import com.recovr.api.entity.User;
import com.recovr.api.entity.UserStatus;
import com.recovr.api.repository.ItemRepository;
import com.recovr.api.repository.UserRepository;
import com.recovr.api.repository.RoleRepository;
import com.recovr.api.entity.Role;
import com.recovr.api.entity.ERole;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

@Service
public class AdminService {

    @Autowired
    private ItemRepository itemRepository;

    @Autowired
    private UserRepository userRepository;

    @Autowired
    private ItemService itemService;

    @Autowired
    private RoleRepository roleRepository;

    @Autowired
    private PasswordEncoder passwordEncoder;

    @Transactional(readOnly = true)
    public AdminDashboardDto getAdminDashboard() {
         AdminDashboardDto dashboard = new AdminDashboardDto();
         dashboard.setTotalItems(itemRepository.count());
         dashboard.setTotalUsers(userRepository.count());
         Map<String, Long> statusMap = new HashMap<>();
         for (ItemStatus status : ItemStatus.values()) {
             statusMap.put(status.name(), itemRepository.countByStatus(status));
         }
         dashboard.setItemsByStatus(statusMap);
         Map<String, Long> categoryMap = new HashMap<>();
         for (ItemCategory cat : ItemCategory.values()) {
             categoryMap.put(cat.name(), itemRepository.countByCategory(cat));
         }
         dashboard.setItemsByCategory(categoryMap);
         dashboard.setTotalAbandoned(itemRepository.countByStatus(ItemStatus.ABANDONED));
         dashboard.setTotalClaimed(itemRepository.countByStatus(ItemStatus.CLAIMED));
         dashboard.setTotalReturned(itemRepository.countByStatus(ItemStatus.RETURNED));
         return dashboard;
    }

    @Transactional(readOnly = true)
    public List<ItemDto> getAllItemsAdmin() {
         List<Item> items = itemRepository.findAll();
         return items.stream().map(itemService::convertToDto).collect(Collectors.toList());
    }

    @Transactional(readOnly = true)
    public List<UserDto> getAllUsersAdmin() {
         List<User> users = userRepository.findAll();
         return users.stream().map(this::convertToUserDto).collect(Collectors.toList());
    }

    @Transactional
    public void deleteItemAdmin(Long id) {
         if (!itemRepository.existsById(id)) { throw new RuntimeException("Item not found"); }
         itemRepository.deleteById(id);
    }

    @Transactional
    public void deleteUserAdmin(Long id) {
         if (!userRepository.existsById(id)) { throw new RuntimeException("User not found"); }
         userRepository.deleteById(id);
    }

    @Transactional
    public ItemDto updateItemAdmin(Long id, ItemDto itemDto) {
         Item item = itemRepository.findById(id).orElseThrow(() -> new RuntimeException("Item not found"));
         itemService.updateItemFromDto(item, itemDto);
         Item savedItem = itemRepository.save(item);
         return itemService.convertToDto(savedItem);
    }

    @Transactional
    public UserDto updateUserAdmin(Long id, UserDto userDto) {
         User user = userRepository.findById(id).orElseThrow(() -> new RuntimeException("User not found"));
         user.setUsername(userDto.getUsername());
         user.setEmail(userDto.getEmail());
         // (Si vous avez une logique de mise à jour des rôles, vous pouvez l'ajouter ici)
         User savedUser = userRepository.save(user);
         return convertToUserDto(savedUser);
    }

    @Transactional
    public void updateUserStatus(Long id, String status) {
        User user = userRepository.findById(id).orElseThrow(() -> new RuntimeException("User not found"));
        
        try {
            UserStatus userStatus = UserStatus.valueOf(status.toUpperCase());
            user.setStatus(userStatus);
            userRepository.save(user);
        } catch (IllegalArgumentException e) {
            throw new RuntimeException("Invalid status: " + status);
        }
    }

    @Transactional
    public int bulkUserOperation(List<Long> userIds, String action) {
        List<User> users = userRepository.findAllById(userIds);
        
        switch (action.toLowerCase()) {
            case "activate":
                users.forEach(user -> user.setStatus(UserStatus.ACTIVE));
                break;
            case "suspend":
                users.forEach(user -> user.setStatus(UserStatus.SUSPENDED));
                break;
            case "delete":
                userRepository.deleteAll(users);
                return users.size();
            default:
                throw new RuntimeException("Invalid action: " + action);
        }
        
        if (!"delete".equals(action.toLowerCase())) {
            userRepository.saveAll(users);
        }
        
        return users.size();
    }

    @Transactional
    public UserDto createUser(Map<String, String> request) {
        String username = request.get("name");
        String email = request.get("email");
        String password = request.get("password");
        String roleStr = request.get("role");
        String statusStr = request.get("status");

        // Validate required fields
        if (username == null || email == null || password == null) {
            throw new RuntimeException("Name, email, and password are required");
        }

        // Check if user already exists
        if (userRepository.existsByEmail(email)) {
            throw new RuntimeException("User with this email already exists");
        }

        // Create new user
        User user = new User();
        user.setUsername(username);
        user.setEmail(email);
        user.setPassword(passwordEncoder.encode(password));
        
        // Parse and set names
        String[] nameParts = username.split(" ", 2);
        user.setFirstName(nameParts[0]);
        if (nameParts.length > 1) {
            user.setLastName(nameParts[1]);
        }

        // Set status
        if (statusStr != null) {
            try {
                UserStatus status = UserStatus.valueOf(statusStr.toUpperCase());
                user.setStatus(status);
            } catch (IllegalArgumentException e) {
                user.setStatus(UserStatus.ACTIVE);
            }
        } else {
            user.setStatus(UserStatus.ACTIVE);
        }

        // Set role
        Role userRole;
        if ("admin".equalsIgnoreCase(roleStr)) {
            userRole = roleRepository.findByName(ERole.ROLE_ADMIN)
                .orElseThrow(() -> new RuntimeException("Admin role not found"));
        } else {
            // Default to user role for now (moderator role doesn't exist in ERole)
            userRole = roleRepository.findByName(ERole.ROLE_USER)
                .orElseThrow(() -> new RuntimeException("User role not found"));
        }
        
        user.getRoles().add(userRole);

        User savedUser = userRepository.save(user);
        return convertToUserDto(savedUser);
    }

    private UserDto convertToUserDto(User user) {
         UserDto dto = new UserDto();
         dto.setId(user.getId());
         dto.setUsername(user.getUsername());
         dto.setEmail(user.getEmail());
         dto.setFirstName(user.getFirstName());
         dto.setLastName(user.getLastName());
         dto.setPhone(user.getPhone());
         dto.setAvatarUrl(user.getAvatarUrl());
         dto.setCreatedAt(user.getCreatedAt());
         dto.setUpdatedAt(user.getUpdatedAt());
         dto.setStatus(user.getStatus() != null ? user.getStatus().name().toLowerCase() : "active");
         
         // Convert roles to string list
         if (user.getRoles() != null && !user.getRoles().isEmpty()) {
             dto.setRoles(user.getRoles().stream()
                 .map(role -> role.getName().name())
                 .collect(Collectors.toList()));
         } else {
             dto.setRoles(List.of("ROLE_USER"));
         }
         
         return dto;
    }

} 