package com.recovr.api.entity;

public enum ClaimStatus {
    PENDING,
    APPROVED,
    REJECTED,
    CANCELLED
} 