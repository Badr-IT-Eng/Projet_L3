package com.recovr.api.entity;

public enum ItemType {
    LOST,
    FOUND
} 