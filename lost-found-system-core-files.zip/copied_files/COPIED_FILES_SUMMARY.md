# Lost & Found System - Copied Files Summary

This directory contains all files related to **map functionality**, **item reporting**, **image matching**, **text search**, and **AI detection** from the lost-found system.

## 📁 Directory Structure

### 🖥️ Frontend Files

#### **Pages (`app/`)**
- `app/map/page.tsx` - Map view page with location display
- `app/report-lost/page.tsx` - Report lost items form
- `app/report/page.tsx` - General reporting page
- `app/lost-items/page.tsx` - View lost items
- `app/found-items/page.tsx` - View found items
- `app/lost-objects/page.tsx` - Lost objects listing
- `app/search/page.tsx` - Search functionality page
- `app/detection/page.tsx` - AI detection interface
- `app/dashboard/page.tsx` - User dashboard
- `app/admin/ai-detection/page.tsx` - Admin AI detection management
- `app/admin/ai-detection/preview/page.tsx` - AI detection preview
- `app/admin/reports/page.tsx` - Admin reports management

#### **API Routes (`app/api/`)**
- `app/api/report-lost/route.ts` - Report lost items API
- `app/api/lost/route.ts` - Lost items API
- `app/api/found/route.ts` - Found items API
- `app/api/lost-objects/route.ts` - Lost objects API
- `app/api/upload/route.ts` - File upload API
- `app/api/search/route.ts` - Search API
- `app/api/search/image/route.ts` - Image search API
- `app/api/dashboard/route.ts` - Dashboard data API
- `app/api/items/[id]/route.ts` - Individual item API
- `app/api/admin/items/` - Admin item management APIs
- `app/api/admin/ai-detection/` - AI detection admin APIs
- `app/api/admin/dashboard/route.ts` - Admin dashboard API
- `app/api/admin/reports/route.ts` - Admin reports API

#### **Components (`components/`)**
- `components/map-viewer.tsx` - Map display component
- `components/map-with-no-ssr.tsx` - Map component without SSR
- `components/ui/location-picker.tsx` - Location selection component
- `components/ui/search-navigation.tsx` - Search navigation
- `components/ui/advanced-search.tsx` - Advanced search interface
- `components/ui/item-card.tsx` - Item display card
- All UI components from `components/ui/` directory

#### **Libraries (`lib/`)**
- `lib/cloudinary.ts` - Image upload and storage
- `lib/api-client.ts` - API client utilities
- `lib/utils.ts` - General utilities
- `lib/ai-detection.ts` - AI detection integration
- `lib/ai/feature-extraction.ts` - Image feature extraction
- `lib/auth-options.ts` - Authentication options
- `lib/models/` - Data models

### 🚀 Backend Files (Spring Boot)

#### **Controllers (`spring-backend/src/main/java/com/recovr/api/controller/`)**
- `ItemController.java` - Item management endpoints
- `SearchController.java` - Search functionality
- `FileController.java` - File upload and management
- `MatchingController.java` - Image matching logic
- `DetectionController.java` - AI detection endpoints
- `AdminController.java` - Admin functionality
- `AuthController.java` - Authentication
- `UserController.java` - User management
- `ClaimRequestController.java` - Claim processing

#### **Services (`spring-backend/src/main/java/com/recovr/api/service/`)**
- `ItemService.java` - Item business logic
- `SearchService.java` - Search business logic
- `FileStorageService.java` - File storage management
- `DetectionService.java` - AI detection service
- `AdminService.java` - Admin operations
- `NotificationService.java` - Notification handling

#### **Entities (`spring-backend/src/main/java/com/recovr/api/entity/`)**
- `Item.java` - Item entity
- `User.java` - User entity
- `DetectionSession.java` - AI detection session
- `DetectedObject.java` - Detected object entity
- `ImageMatching.java` - Image matching entity
- `SearchRequest.java` - Search request entity
- `ClaimRequest.java` - Claim request entity
- `Notification.java` - Notification entity
- All enum classes (ItemStatus, ItemCategory, UserStatus, etc.)

#### **DTOs (`spring-backend/src/main/java/com/recovr/api/dto/`)**
- `ItemDto.java` - Item data transfer object
- `SearchRequestDto.java` - Search request DTO
- `DetectedObjectDto.java` - Detected object DTO
- `ImageMatchingDto.java` - Image matching DTO
- `ClaimRequestDto.java` - Claim request DTO
- `UserDto.java` - User DTO
- `AdminDashboardDto.java` - Admin dashboard DTO
- Authentication DTOs (LoginRequest, SignupRequest, JwtResponse, etc.)

#### **Repositories (`spring-backend/src/main/java/com/recovr/api/repository/`)**
- `ItemRepository.java` - Item data access
- `SearchRequestRepository.java` - Search data access
- `DetectionSessionRepository.java` - Detection session data access
- `DetectedObjectRepository.java` - Detected object data access
- `ImageMatchingRepository.java` - Image matching data access
- `UserRepository.java` - User data access
- `ClaimRequestRepository.java` - Claim request data access
- `NotificationRepository.java` - Notification data access
- `RoleRepository.java` - Role data access

### 🐍 Python Services

#### **Image Matching Service (`matching-service/`)**
- `image_matcher.py` - Core image matching logic
- `image_matcher_api.py` - API interface for image matching
- `test_matching.py` - Matching service tests
- Complete Python virtual environment and dependencies

#### **AI Detection Service (`detection-service/`)**
- `object_detector.py` - Object detection using YOLO
- `start_detection.py` - Detection service starter
- `run_detection.py` - Detection runner
- Complete detection service implementation

#### **Scripts (`scripts/`)**
- `yolo_detector.py` - YOLO detection script
- Additional utility scripts

### 📝 Configuration Files
- `object_detector.py` - Main object detector
- `config_improved.py` - Enhanced configuration
- `test-detection.js` - Detection testing
- `test-simple-detection.js` - Simple detection test
- `AI_DETECTION_README.md` - AI detection documentation

## 🔧 Key Features Included

### 🗺️ **Map Functionality**
- Interactive map display using Mapbox/Google Maps
- Location picker component
- Geolocation services
- Map-based item visualization

### 📝 **Item Reporting**
- Report lost items form
- Report found items form
- Item categorization and tagging
- Location-based reporting
- Image upload with items

### 🔍 **Search & Matching**
- Text-based search
- Image-based search
- Advanced search filters
- Location-based search
- AI-powered matching algorithms

### 🤖 **AI Detection**
- YOLO-based object detection
- Real-time video analysis
- Image feature extraction
- Automated item categorization
- Detection confidence scoring

### 📱 **User Interface**
- Responsive design components
- Interactive search navigation
- Advanced search interfaces
- Item display cards
- Admin management panels

## 🚀 Usage

These files represent a complete lost & found system with:
- **Frontend**: React/Next.js components and pages
- **Backend**: Spring Boot REST APIs
- **AI Services**: Python-based image matching and object detection
- **Database**: JPA entities and repositories
- **Authentication**: JWT-based security

All files maintain their original structure and dependencies for seamless integration into any similar project.